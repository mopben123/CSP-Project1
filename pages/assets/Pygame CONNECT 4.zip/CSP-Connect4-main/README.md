The repository of Team 4's game project of Connect 4
